//
//  NameAndColorCell.swift
//  tableCells
//
//  Created by student on 3/5/17.
//  Copyright © 2017 jhott-leitsch. All rights reserved.
//

import UIKit

class NameAndColorCell: UITableViewCell {
    var name: String = "" {
        didSet {
            if (name != oldValue){
                    nameLable.text = name}
        }}

var color: String = "" {
        didSet{
            if (color != oldValue){
                colorLable.text = color}
        }}

    @IBOutlet var nameLable: UILabel!
    @IBOutlet var colorLable: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
