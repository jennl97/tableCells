//
//  NameAndColorCellTableViewCell.swift
//  tableCells
//
//  Created by student on 3/5/17.
//  Copyright © 2017 jhott-leitsch. All rights reserved.
//

import UIKit

class NameAndColorCellTableViewCell: UITableViewCell {
    var name: String = ""
    var color: String = ""
    var nameLable: UILabel!
    var colorLable: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
